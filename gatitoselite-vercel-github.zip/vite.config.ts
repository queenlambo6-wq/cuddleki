import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    base: './',
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          contacto: path.resolve(__dirname, 'contacto.html'),
          contrato: path.resolve(__dirname, 'contrato-de-venta.html'),
          envio: path.resolve(__dirname, 'envio-y-entrega.html'),
          garantia: path.resolve(__dirname, 'garantia-de-salud.html'),
          gatitos: path.resolve(__dirname, 'gatitos.html'),
          faq: path.resolve(__dirname, 'preguntas-frecuentes.html'),
          razas: path.resolve(__dirname, 'razas.html'),
          sobreNosotros: path.resolve(__dirname, 'sobre-nosotros.html'),
          testimonios: path.resolve(__dirname, 'testimonios.html'),
          vacunaciones: path.resolve(__dirname, 'vacunaciones.html'),
          descargar: path.resolve(__dirname, 'descargar.html'),
          azulRuso: path.resolve(__dirname, 'razas/azul-ruso.html'),
          bengali: path.resolve(__dirname, 'razas/bengali.html'),
          britishShorthair: path.resolve(__dirname, 'razas/british-shorthair.html'),
          maineCoon: path.resolve(__dirname, 'razas/maine-coon.html'),
          persa: path.resolve(__dirname, 'razas/persa.html'),
          ragdoll: path.resolve(__dirname, 'razas/ragdoll.html'),
          siames: path.resolve(__dirname, 'razas/siames.html'),
          siberiano: path.resolve(__dirname, 'razas/siberiano.html'),
          sphynx: path.resolve(__dirname, 'razas/sphynx.html'),
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
