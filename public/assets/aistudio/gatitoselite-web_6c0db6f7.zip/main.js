// Menú móvil
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav');
if (burger) {
  burger.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
    document.body.style.overflow = open ? 'hidden' : '';
  });
}

document.getElementById('year').textContent = new Date().getFullYear();

// Filtros de la página de gatitos
const grid = document.getElementById('kgrid');
if (grid) {
  const state = { breed: 'all', sex: 'all' };
  const apply = () => {
    let n = 0;
    grid.querySelectorAll('.kmini').forEach(card => {
      const show = (state.breed === 'all' || card.dataset.breed === state.breed) &&
                   (state.sex === 'all' || card.dataset.sex === state.sex);
      card.hidden = !show;
      if (show) n++;
    });
    document.getElementById('kcount').textContent = n;
  };
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const key = 'breed' in chip.dataset ? 'breed' : 'sex';
      chip.parentElement.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      state[key] = chip.dataset[key];
      apply();
    });
  });
  const pre = new URLSearchParams(location.search).get('raza');
  if (pre) document.querySelector(`.chip[data-breed="${pre}"]`)?.click();
}

// Ampliar fotos
const lb = document.querySelector('.lightbox');
document.querySelectorAll('img[data-zoom]').forEach(img => {
  img.addEventListener('click', () => {
    lb.querySelector('img').src = img.src;
    lb.querySelector('img').alt = img.alt;
    lb.hidden = false;
  });
});
lb?.addEventListener('click', e => { if (e.target !== lb.querySelector('img')) lb.hidden = true; });
document.addEventListener('keydown', e => { if (e.key === 'Escape' && lb) lb.hidden = true; });

// Formulario de contacto → WhatsApp o email (sitio estático, sin servidor)
const form = document.getElementById('contact-form');
if (form && window.SITE_CONTACT) {
  const C = window.SITE_CONTACT;
  const q = new URLSearchParams(location.search);
  if (q.get('gatito')) form.gatito.value = q.get('gatito');
  if (q.get('raza')) form.raza.value = q.get('raza');
  if (q.get('adoptar')) form.mensaje.value = 'Me gustaría adoptar a este gatito. ¿Cuáles son los siguientes pasos?';
  if (q.get('gatito')) setTimeout(() => document.getElementById('contacto')?.scrollIntoView(), 50);

  let via = 'wa';
  form.querySelectorAll('button[type=submit]').forEach(b => b.addEventListener('click', () => { via = b.dataset.via; }));

  form.addEventListener('submit', e => {
    e.preventDefault();
    const required = ['nombre', 'apellidos', 'email', 'telefono'];
    let ok = true;
    required.forEach(n => {
      const el = form[n];
      const bad = !el.value.trim() || (n === 'email' && !/^\S+@\S+\.\S+$/.test(el.value));
      el.classList.toggle('invalid', bad);
      if (bad) ok = false;
    });
    form.querySelector('.form-error').hidden = ok;
    if (!ok) return;

    const f = n => form[n].value.trim();
    const lines = [
      `Hola ${C.name}, quiero hacer una consulta:`,
      `Nombre: ${f('nombre')} ${f('apellidos')}`,
      `Email: ${f('email')}`,
      `Teléfono: ${f('telefono')}`,
      f('ciudad') && `Ciudad: ${f('ciudad')}`,
      f('raza') && `Raza de interés: ${C.breeds[f('raza')] || 'No estoy seguro'}`,
      f('gatito') && `Gatito: ${f('gatito')}`,
      f('mensaje') && `Mensaje: ${f('mensaje')}`,
    ].filter(Boolean).join('\n');

    if (via === 'mail') {
      location.href = `mailto:${C.email}?subject=${encodeURIComponent('Consulta de adopción - ' + f('nombre'))}&body=${encodeURIComponent(lines)}`;
    } else {
      window.open(`https://wa.me/${C.wa}?text=${encodeURIComponent(lines)}`, '_blank', 'noopener');
    }
  });
}

// Formulario de opiniones → WhatsApp o email
const review = document.getElementById('review-form');
if (review && window.SITE_CONTACT) {
  const C = window.SITE_CONTACT;
  let via = 'wa';
  review.querySelectorAll('button[type=submit]').forEach(b => b.addEventListener('click', () => { via = b.dataset.via; }));
  review.addEventListener('submit', e => {
    e.preventDefault();
    let ok = true;
    ['nombre', 'gatito', 'opinion'].forEach(n => {
      const bad = !review[n].value.trim();
      review[n].classList.toggle('invalid', bad);
      if (bad) ok = false;
    });
    review.querySelector('.form-error').hidden = ok;
    if (!ok) return;
    const f = n => review[n].value.trim();
    const text = [
      `Hola ${C.name}, quiero dejar mi opinión:`,
      `Nombre: ${f('nombre')}`,
      f('ciudad') && `Ciudad: ${f('ciudad')}`,
      `Gatito: ${f('gatito')}`,
      `Valoración: ${'★'.repeat(+f('estrellas'))}`,
      `Opinión: ${f('opinion')}`,
      'Autorizo a publicar esta opinión en la web.',
    ].filter(Boolean).join('\n');
    if (via === 'mail') {
      location.href = `mailto:${C.email}?subject=${encodeURIComponent('Opinión de ' + f('nombre'))}&body=${encodeURIComponent(text)}`;
    } else {
      window.open(`https://wa.me/${C.wa}?text=${encodeURIComponent(text)}`, '_blank', 'noopener');
    }
  });
}
